import Vue from 'vue'
import { FontAwesomeIcon } from "@fortawesome/vue-fontawesome";
Vue.component('vue-fontawesome', FontAwesomeIcon);

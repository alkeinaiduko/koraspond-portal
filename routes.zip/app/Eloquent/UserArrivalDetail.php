<?php

namespace App\Eloquent;

use Illuminate\Database\Eloquent\Model;

class UserArrivalDetail extends Model
{
    protected $fillable = ['*'];
}

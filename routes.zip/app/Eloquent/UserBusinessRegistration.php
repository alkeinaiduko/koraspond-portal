<?php

namespace App\Eloquent;

use Illuminate\Database\Eloquent\Model;

class UserBusinessRegistration extends Model
{
    protected $fillable = ['*'];
}

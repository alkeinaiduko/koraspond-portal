<?php

namespace App\Eloquent;

use Illuminate\Database\Eloquent\Model;

class UserBasicInfo extends Model
{
    protected $fillable = ['*'];
}

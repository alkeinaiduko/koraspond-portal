<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            UserSeeder::class,
            AdminsSeeder::class,
            UserTypeSeeder::class,
            MeetingProfileSeeder::class,
            InterestSeeder::class,
            PartnershipSeeder::class,
            MeetingRequestSeeder::class,
            TagsSeeder::class
        ]);
    }
}

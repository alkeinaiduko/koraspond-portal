  
@extends('layouts.admin', ['vueModulePath' => 'js/modules/meetingrequest/main.js'])
@section('page_title', 'Meeting Request')

@section('content')
    <meeting-request />
@stop
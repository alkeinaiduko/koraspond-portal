@extends('layouts.app')
@section('page_title', 'Login')

@section('content')
    <admin-login />
@stop

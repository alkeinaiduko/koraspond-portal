@extends('layouts.portal', ['vueModulePath' => 'js/modules/meeting-available/main.js'])
@section('page_title', 'Meeting Available')

@section('content')
    <meeting-available />
@stop

@extends('layouts.app', ['vueModulePath' => 'js/modules/homepage/main.js'])
@section('page_title', 'Welcome to Koraspond')

@section('content')
    <home-page />
@stop

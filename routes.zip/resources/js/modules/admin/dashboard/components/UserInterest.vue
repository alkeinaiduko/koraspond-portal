<template>
    <div class="user-interest__container">
        <h4>Interest</h4>
        <el-tag
            type="info"
            size="medium"
        >
            Animation
        </el-tag>
        <el-tag
            type="info"
            size="medium"
        >
            Engineering
        </el-tag>
        <el-tag
            type="info"
            size="medium"
        >
            Artificial Intelligence
        </el-tag>
        <el-tag
            type="info"
            size="medium"
        >
            Science
        </el-tag>
        <el-tag
            type="info"
            size="medium"
        >
            Software Development
        </el-tag>
    </div>
</template>

<script>
    export default {

    }
</script>

<style>

</style>
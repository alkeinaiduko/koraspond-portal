<template>
    <div class="user-education__container">
        <h4>Education</h4>
        <div>
            <h5>KSR University</h5>
            <p>Electronics & Instrumentation</p>
            <p>2011 - 2015</p>
        </div>
    </div>
</template>

<script>
    export default {

    }
</script>

<style>

</style>
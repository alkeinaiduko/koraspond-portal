<template>
    <div class="user-about__container">
        <h4>About</h4>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s... <a href="#">More</a></p>
    </div>
</template>

<script>
    export default {

    }
</script>

<style>

</style>
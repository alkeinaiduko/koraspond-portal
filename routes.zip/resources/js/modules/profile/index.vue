<template>
    <div>Profile</div>
</template>

<script>
    export default {
        name: 'Profile'
    }
</script>

<style lang="sass">
    @import "~/../sass/modules/profile/_all"
</style>

<template>
    <div class="portal__container wrapper">
        <div class="portal__content">
            <div class="portal__content--left">
                <card-container class="user-information">
                    <el-button
                        class="edit-btn"
                        type="info"
                        plain
                        circle
                        size="small"
                        icon="el-icon-edit"
                    />
                    <user-info :data="user" />
                    <user-about />
                    <user-education />
                    <user-interest />
                </card-container>
            </div>
            <div class="portal__content--right">
                <card-container class="nav-menu">
                    <div>
                        <el-menu
                            :default-active="activeIndex"
                            class="el-menu-demo"
                            mode="horizontal"
                            active-text-color="#F7B85B"
                        >
                            <el-menu-item
                                v-for="(tab, key) in tabs"
                                :key="key"
                                :index="tab.id"
                                @click="currentTab = tab.component"
                            >
                                {{ tab.title }}
                            </el-menu-item>
                        </el-menu>
                        <el-button
                            type="primary"
                            plain
                            icon="el-icon-plus"
                            @click="showProjectForm = true"
                        >
                            Create Project
                        </el-button>
                    </div>
                </card-container>
                <!-- <ul class="content-list">
                    <li
                        v-for="(project, key) in projects"
                        :key="key"
                    >
                        <card-container class="project">
                            <project-list-item
                                :data="project"
                                @open-details="openDetails(project)"
                            />
                        </card-container>
                    </li>
                </!-->
                <project-details
                    v-if="openProjectDetails"
                    :data="projectDetail"
                    @close="openProjectDetails = false"
                />
                <section class="content">
                    <component
                        :is="currentTabComponent"
                        class="tab"
                    />
                </section>
            </div>
        </div>
        <create-project
            :show="showProjectForm"
            @close="showProjectForm = !showProjectForm"
        />
    </div>
</template>

<script>
    import CardContainer from '~/common/CardContainer'
    import UserInfo from './components/UserInfo'
    import UserAbout from './components/UserAbout'
    import UserEducation from './components/UserEducation'
    import UserInterest from './components/UserInterest'
    import NavMenu from './components/NavMenu'
    import ProjectListItem from './components/ProjectListItem'
    import ProjectDetails from './components/ProjectDetails'
    import MeetingRequest from './components/MeetingRequest'
    import ProjectList from './components/ProjectList'
    import CreateProject from './components/CreateProject'

    export default {
        name: 'Dashboard',
        components: {
            CardContainer,
            UserInfo,
            UserAbout,
            UserEducation,
            UserInterest,
            NavMenu,
            ProjectListItem,
            ProjectDetails,
            MeetingRequest,
            ProjectList,
            CreateProject
        },
        props: {
            user: Object
        },
        data() {
            return {
                openProjectDetails: false,
                projectDetail: {},
                test: [],
                projects: [],
                activeIndex: '1',
                activeIndex2: '1',
                currentTab: "project-list",
                tabs: [
                    { id:"1", component: "project-list", title: "Projects" },
                    { id:"2", component: "meeting-request", title: "Meeting Request" }
                ],
                showProjectForm: false,
            }
        },
        computed: {
            currentTabComponent(){
                return this.currentTab.toLowerCase();
            }
        },
        methods: {
            openDetails(data) {
                this.projectDetail = data
                this.openProjectDetails = true
            }
        }
    }
</script>

<style lang="sass">
    @import "~/../sass/modules/portal/dashboard/_all"
</style>